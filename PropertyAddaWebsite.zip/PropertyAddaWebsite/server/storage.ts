import { 
  users, type User, type InsertUser,
  properties, type Property, type InsertProperty,
  services, type Service, type InsertService,
  serviceFeatures, type ServiceFeature, type InsertServiceFeature,
  serviceRequests, type ServiceRequest, type InsertServiceRequest,
  contactRequests, type ContactRequest, type InsertContactRequest
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Property methods
  getProperty(id: number): Promise<Property | undefined>;
  getAllProperties(): Promise<Property[]>;
  getPropertiesByCity(city: string): Promise<Property[]>;
  getPropertiesByType(propertyType: string): Promise<Property[]>;
  createProperty(property: InsertProperty): Promise<Property>;
  
  // Service methods
  getService(id: number): Promise<Service | undefined>;
  getServiceBySlug(slug: string): Promise<Service | undefined>;
  getAllServices(): Promise<Service[]>;
  createService(service: InsertService): Promise<Service>;
  
  // Service feature methods
  getServiceFeatures(serviceId: number): Promise<ServiceFeature[]>;
  createServiceFeature(feature: InsertServiceFeature): Promise<ServiceFeature>;
  
  // Service request methods
  createServiceRequest(request: InsertServiceRequest): Promise<ServiceRequest>;
  getServiceRequests(): Promise<ServiceRequest[]>;
  updateServiceRequestStatus(id: number, status: string): Promise<ServiceRequest | undefined>;
  
  // Contact request methods
  createContactRequest(request: InsertContactRequest): Promise<ContactRequest>;
  getContactRequests(): Promise<ContactRequest[]>;
  updateContactRequestStatus(id: number, status: string): Promise<ContactRequest | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private properties: Map<number, Property>;
  private services: Map<number, Service>;
  private serviceFeatures: Map<number, ServiceFeature>;
  private serviceRequests: Map<number, ServiceRequest>;
  private contactRequests: Map<number, ContactRequest>;
  
  private userCurrentId: number;
  private propertyCurrentId: number;
  private serviceCurrentId: number;
  private serviceFeatureCurrentId: number;
  private serviceRequestCurrentId: number;
  private contactRequestCurrentId: number;

  constructor() {
    this.users = new Map();
    this.properties = new Map();
    this.services = new Map();
    this.serviceFeatures = new Map();
    this.serviceRequests = new Map();
    this.contactRequests = new Map();
    
    this.userCurrentId = 1;
    this.propertyCurrentId = 1;
    this.serviceCurrentId = 1;
    this.serviceFeatureCurrentId = 1;
    this.serviceRequestCurrentId = 1;
    this.contactRequestCurrentId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const now = new Date();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Property methods
  async getProperty(id: number): Promise<Property | undefined> {
    return this.properties.get(id);
  }
  
  async getAllProperties(): Promise<Property[]> {
    return Array.from(this.properties.values());
  }
  
  async getPropertiesByCity(city: string): Promise<Property[]> {
    return Array.from(this.properties.values()).filter(
      (property) => property.city === city
    );
  }
  
  async getPropertiesByType(propertyType: string): Promise<Property[]> {
    return Array.from(this.properties.values()).filter(
      (property) => property.propertyType === propertyType
    );
  }
  
  async createProperty(insertProperty: InsertProperty): Promise<Property> {
    const id = this.propertyCurrentId++;
    const now = new Date();
    const property: Property = { 
      ...insertProperty, 
      id, 
      createdAt: now 
    };
    this.properties.set(id, property);
    return property;
  }
  
  // Service methods
  async getService(id: number): Promise<Service | undefined> {
    return this.services.get(id);
  }
  
  async getServiceBySlug(slug: string): Promise<Service | undefined> {
    return Array.from(this.services.values()).find(
      (service) => service.slug === slug
    );
  }
  
  async getAllServices(): Promise<Service[]> {
    return Array.from(this.services.values());
  }
  
  async createService(insertService: InsertService): Promise<Service> {
    const id = this.serviceCurrentId++;
    const service: Service = { ...insertService, id };
    this.services.set(id, service);
    return service;
  }
  
  // Service feature methods
  async getServiceFeatures(serviceId: number): Promise<ServiceFeature[]> {
    return Array.from(this.serviceFeatures.values()).filter(
      (feature) => feature.serviceId === serviceId
    );
  }
  
  async createServiceFeature(insertFeature: InsertServiceFeature): Promise<ServiceFeature> {
    const id = this.serviceFeatureCurrentId++;
    const feature: ServiceFeature = { ...insertFeature, id };
    this.serviceFeatures.set(id, feature);
    return feature;
  }
  
  // Service request methods
  async createServiceRequest(insertRequest: InsertServiceRequest): Promise<ServiceRequest> {
    const id = this.serviceRequestCurrentId++;
    const now = new Date();
    const request: ServiceRequest = { 
      ...insertRequest, 
      id, 
      createdAt: now 
    };
    this.serviceRequests.set(id, request);
    return request;
  }
  
  async getServiceRequests(): Promise<ServiceRequest[]> {
    return Array.from(this.serviceRequests.values());
  }
  
  async updateServiceRequestStatus(id: number, status: string): Promise<ServiceRequest | undefined> {
    const request = this.serviceRequests.get(id);
    if (!request) return undefined;
    
    const updatedRequest = { ...request, status };
    this.serviceRequests.set(id, updatedRequest);
    return updatedRequest;
  }
  
  // Contact request methods
  async createContactRequest(insertRequest: InsertContactRequest): Promise<ContactRequest> {
    const id = this.contactRequestCurrentId++;
    const now = new Date();
    const request: ContactRequest = { 
      ...insertRequest, 
      id, 
      createdAt: now 
    };
    this.contactRequests.set(id, request);
    return request;
  }
  
  async getContactRequests(): Promise<ContactRequest[]> {
    return Array.from(this.contactRequests.values());
  }
  
  async updateContactRequestStatus(id: number, status: string): Promise<ContactRequest | undefined> {
    const request = this.contactRequests.get(id);
    if (!request) return undefined;
    
    const updatedRequest = { ...request, status };
    this.contactRequests.set(id, updatedRequest);
    return updatedRequest;
  }
}

export const storage = new MemStorage();
