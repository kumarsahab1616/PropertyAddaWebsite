import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertPropertySchema, 
  insertServiceSchema, 
  insertServiceFeatureSchema,
  insertServiceRequestSchema,
  insertContactRequestSchema
} from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Error handling middleware for Zod validation errors
  const handleZodError = (error: unknown, res: Response) => {
    if (error instanceof ZodError) {
      return res.status(400).json({ 
        message: "Validation error", 
        errors: error.errors 
      });
    }
    console.error("Unexpected error:", error);
    return res.status(500).json({ message: "Internal server error" });
  };

  // User Routes
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username or email already exists
      const existingUsername = await storage.getUserByUsername(userData.username);
      if (existingUsername) {
        return res.status(400).json({ message: "Username already taken" });
      }
      
      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already registered" });
      }
      
      // In a real app, you would hash the password here
      const user = await storage.createUser(userData);
      // Don't return the password in the response
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      handleZodError(error, res);
    }
  });

  // Property Routes
  app.get("/api/properties", async (req, res) => {
    const { city, type } = req.query;
    
    try {
      let properties;
      
      if (city && typeof city === 'string') {
        properties = await storage.getPropertiesByCity(city);
      } else if (type && typeof type === 'string') {
        properties = await storage.getPropertiesByType(type);
      } else {
        properties = await storage.getAllProperties();
      }
      
      res.json(properties);
    } catch (error) {
      console.error("Error fetching properties:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/properties/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    
    try {
      const property = await storage.getProperty(id);
      
      if (!property) {
        return res.status(404).json({ message: "Property not found" });
      }
      
      res.json(property);
    } catch (error) {
      console.error("Error fetching property:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/properties", async (req, res) => {
    try {
      const propertyData = insertPropertySchema.parse(req.body);
      const property = await storage.createProperty(propertyData);
      res.status(201).json(property);
    } catch (error) {
      handleZodError(error, res);
    }
  });

  // Service Routes
  app.get("/api/services", async (_req, res) => {
    try {
      const services = await storage.getAllServices();
      
      // Add features to each service
      const servicesWithFeatures = await Promise.all(
        services.map(async (service) => {
          const features = await storage.getServiceFeatures(service.id);
          return {
            ...service,
            features: features.map(f => f.feature)
          };
        })
      );
      
      res.json(servicesWithFeatures);
    } catch (error) {
      console.error("Error fetching services:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/services/:slug", async (req, res) => {
    const slug = req.params.slug;
    
    try {
      const service = await storage.getServiceBySlug(slug);
      
      if (!service) {
        return res.status(404).json({ message: "Service not found" });
      }
      
      // Get features for this service
      const features = await storage.getServiceFeatures(service.id);
      
      res.json({
        ...service,
        features: features.map(f => f.feature)
      });
    } catch (error) {
      console.error("Error fetching service:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/services", async (req, res) => {
    try {
      const serviceData = insertServiceSchema.parse(req.body);
      const service = await storage.createService(serviceData);
      
      // Handle features if included
      const { features } = req.body;
      if (Array.isArray(features)) {
        await Promise.all(
          features.map(async (feature) => {
            const featureData = insertServiceFeatureSchema.parse({
              serviceId: service.id,
              feature
            });
            await storage.createServiceFeature(featureData);
          })
        );
      }
      
      res.status(201).json(service);
    } catch (error) {
      handleZodError(error, res);
    }
  });

  // Service Request Routes
  app.post("/api/service-requests", async (req, res) => {
    try {
      const requestData = insertServiceRequestSchema.parse(req.body);
      const serviceRequest = await storage.createServiceRequest(requestData);
      res.status(201).json(serviceRequest);
    } catch (error) {
      handleZodError(error, res);
    }
  });

  app.get("/api/service-requests", async (_req, res) => {
    try {
      const requests = await storage.getServiceRequests();
      res.json(requests);
    } catch (error) {
      console.error("Error fetching service requests:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/service-requests/:id/status", async (req, res) => {
    const id = parseInt(req.params.id);
    const { status } = req.body;
    
    if (!status || typeof status !== 'string') {
      return res.status(400).json({ message: "Status is required" });
    }
    
    try {
      const updatedRequest = await storage.updateServiceRequestStatus(id, status);
      
      if (!updatedRequest) {
        return res.status(404).json({ message: "Service request not found" });
      }
      
      res.json(updatedRequest);
    } catch (error) {
      console.error("Error updating service request:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Contact Request Routes
  app.post("/api/contact-requests", async (req, res) => {
    try {
      const requestData = insertContactRequestSchema.parse(req.body);
      const contactRequest = await storage.createContactRequest(requestData);
      res.status(201).json(contactRequest);
    } catch (error) {
      handleZodError(error, res);
    }
  });

  app.get("/api/contact-requests", async (_req, res) => {
    try {
      const requests = await storage.getContactRequests();
      res.json(requests);
    } catch (error) {
      console.error("Error fetching contact requests:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/contact-requests/:id/status", async (req, res) => {
    const id = parseInt(req.params.id);
    const { status } = req.body;
    
    if (!status || typeof status !== 'string') {
      return res.status(400).json({ message: "Status is required" });
    }
    
    try {
      const updatedRequest = await storage.updateContactRequestStatus(id, status);
      
      if (!updatedRequest) {
        return res.status(404).json({ message: "Contact request not found" });
      }
      
      res.json(updatedRequest);
    } catch (error) {
      console.error("Error updating contact request:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
