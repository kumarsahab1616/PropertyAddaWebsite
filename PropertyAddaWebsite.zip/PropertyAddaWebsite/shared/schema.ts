import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  phone: text("phone"),
  userType: text("user_type").default("user").notNull(), // user, agent, admin
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  fullName: true,
  phone: true,
  userType: true,
});

// Properties table
export const properties = pgTable("properties", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  location: text("location").notNull(),
  city: text("city").notNull(),
  price: integer("price").notNull(),
  pricePerSqFt: integer("price_per_sqft").notNull(),
  size: integer("size").notNull(),
  bedrooms: integer("bedrooms").notNull(),
  status: text("status").notNull(), // Ready to Move, Under Construction
  isRERAApproved: boolean("is_rera_approved").default(false).notNull(),
  isPremium: boolean("is_premium").default(false).notNull(),
  isFeatured: boolean("is_featured").default(false).notNull(),
  image: text("image").notNull(),
  propertyType: text("property_type").notNull(), // Apartments, Houses & Villas, etc.
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPropertySchema = createInsertSchema(properties).pick({
  title: true,
  location: true,
  city: true,
  price: true,
  pricePerSqFt: true,
  size: true,
  bedrooms: true,
  status: true,
  isRERAApproved: true,
  isPremium: true,
  isFeatured: true,
  image: true,
  propertyType: true,
});

// Services table
export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  image: text("image").notNull(),
  description: text("description").notNull(),
  detailImage: text("detail_image").notNull(),
  detailDescription: text("detail_description").notNull(),
});

export const insertServiceSchema = createInsertSchema(services).pick({
  name: true,
  slug: true,
  image: true,
  description: true,
  detailImage: true,
  detailDescription: true,
});

// Service features
export const serviceFeatures = pgTable("service_features", {
  id: serial("id").primaryKey(),
  serviceId: integer("service_id").notNull(),
  feature: text("feature").notNull(),
});

export const insertServiceFeatureSchema = createInsertSchema(serviceFeatures).pick({
  serviceId: true,
  feature: true,
});

// Service requests table
export const serviceRequests = pgTable("service_requests", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  serviceType: text("service_type").notNull(),
  propertyType: text("property_type").notNull(),
  address: text("address").notNull(),
  message: text("message"),
  date: text("date").notNull(),
  status: text("status").default("pending").notNull(), // pending, confirmed, completed, cancelled
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertServiceRequestSchema = createInsertSchema(serviceRequests).pick({
  name: true,
  email: true,
  phone: true,
  serviceType: true,
  propertyType: true,
  address: true,
  message: true,
  date: true,
  status: true,
});

// Contact requests table
export const contactRequests = pgTable("contact_requests", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  requirement: text("requirement").notNull(),
  message: text("message").notNull(),
  status: text("status").default("pending").notNull(), // pending, contacted, closed
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertContactRequestSchema = createInsertSchema(contactRequests).pick({
  name: true,
  email: true,
  phone: true,
  requirement: true,
  message: true,
  status: true,
});

// Type exports
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertProperty = z.infer<typeof insertPropertySchema>;
export type Property = typeof properties.$inferSelect;

export type InsertService = z.infer<typeof insertServiceSchema>;
export type Service = typeof services.$inferSelect;

export type InsertServiceFeature = z.infer<typeof insertServiceFeatureSchema>;
export type ServiceFeature = typeof serviceFeatures.$inferSelect;

export type InsertServiceRequest = z.infer<typeof insertServiceRequestSchema>;
export type ServiceRequest = typeof serviceRequests.$inferSelect;

export type InsertContactRequest = z.infer<typeof insertContactRequestSchema>;
export type ContactRequest = typeof contactRequests.$inferSelect;
