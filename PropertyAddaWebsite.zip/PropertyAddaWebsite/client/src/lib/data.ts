// City data
export const cities = [
  { id: 1, name: "Delhi NCR", propertyCount: 890, slug: "delhi-ncr" },
  { id: 2, name: "Mumbai", propertyCount: 1240, slug: "mumbai" },
  { id: 3, name: "Bangalore", propertyCount: 950, slug: "bangalore" },
  { id: 4, name: "Hyderabad", propertyCount: 780, slug: "hyderabad" },
  { id: 5, name: "Pune", propertyCount: 670, slug: "pune" },
  { id: 6, name: "Chennai", propertyCount: 540, slug: "chennai" },
  { id: 7, name: "Kolkata", propertyCount: 480, slug: "kolkata" },
  { id: 8, name: "Ahmedabad", propertyCount: 320, slug: "ahmedabad" },
  { id: 9, name: "Jaipur", propertyCount: 290, slug: "jaipur" },
  { id: 10, name: "Lucknow", propertyCount: 210, slug: "lucknow" },
  { id: 11, name: "Noida", propertyCount: 430, slug: "noida" },
  { id: 12, name: "Gurgaon", propertyCount: 520, slug: "gurgaon" },
  { id: 13, name: "Ghaziabad", propertyCount: 280, slug: "ghaziabad" },
  { id: 14, name: "Greater Noida", propertyCount: 320, slug: "greater-noida" },
  { id: 15, name: "Chandigarh", propertyCount: 190, slug: "chandigarh" },
  { id: 16, name: "Navi Mumbai", propertyCount: 340, slug: "navi-mumbai" },
  { id: 17, name: "Thane", propertyCount: 410, slug: "thane" },
  { id: 18, name: "Faridabad", propertyCount: 180, slug: "faridabad" },
  { id: 19, name: "Coimbatore", propertyCount: 150, slug: "coimbatore" },
  { id: 20, name: "Indore", propertyCount: 170, slug: "indore" },
  { id: 21, name: "Kochi", propertyCount: 160, slug: "kochi" },
  { id: 22, name: "Nagpur", propertyCount: 140, slug: "nagpur" },
  { id: 23, name: "Surat", propertyCount: 180, slug: "surat" },
  { id: 24, name: "Visakhapatnam", propertyCount: 130, slug: "visakhapatnam" },
  { id: 25, name: "Vadodara", propertyCount: 120, slug: "vadodara" },
  { id: 26, name: "Bhopal", propertyCount: 110, slug: "bhopal" },
  { id: 27, name: "Bhubaneswar", propertyCount: 100, slug: "bhubaneswar" },
  { id: 28, name: "Mysore", propertyCount: 90, slug: "mysore" },
];

// Location data
export const locations = [
  { id: 1, name: "Sector 62", propertyCount: 240, city: "Delhi NCR" },
  { id: 2, name: "Sector 45", propertyCount: 185, city: "Delhi NCR" },
  { id: 3, name: "Whitefield", propertyCount: 320, city: "Bangalore" },
  { id: 4, name: "Indirapuram", propertyCount: 150, city: "Delhi NCR" },
  { id: 5, name: "South Delhi", propertyCount: 210, city: "Delhi NCR" },
  { id: 6, name: "Powai", propertyCount: 175, city: "Mumbai" },
];

// Service data
export const services = [
  {
    id: 1,
    name: "Painting Services",
    slug: "painting",
    image: "https://images.unsplash.com/photo-1562259929-b4e1fd3aef09?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=350",
    description: "Professional painting services for your home with quality finishes.",
    detailImage: "https://images.unsplash.com/photo-1589939705384-5185137a7f0f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=700&h=500",
    detailDescription: "Transform your home with our professional painting services. Our expert painters use quality materials and techniques to deliver perfect finishes.",
    features: [
      "Interior and exterior painting solutions",
      "Texture and special finishes available",
      "Free color consultation and estimates",
      "Quality assurance and timely completion"
    ]
  },
  {
    id: 2,
    name: "Electrician Services",
    slug: "electrician",
    image: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=350",
    description: "Expert electrical repairs, installations, and maintenance for your home.",
    detailImage: "https://images.unsplash.com/photo-1621905252507-b35492cc74b4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=700&h=500",
    detailDescription: "Our certified electricians provide complete electrical solutions for your home, ensuring safety and efficiency in every job.",
    features: [
      "Electrical repairs and troubleshooting",
      "New installations and wiring",
      "Emergency electrical services",
      "Safety inspections and upgrades"
    ]
  },
  {
    id: 3,
    name: "Plumbing Services",
    slug: "plumbing",
    image: "https://images.unsplash.com/photo-1580256081112-e49377338b7f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=350",
    description: "Professional plumbing solutions for leaks, installations, and repairs.",
    detailImage: "https://images.unsplash.com/photo-1542013936693-884638332954?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=700&h=500",
    detailDescription: "Our professional plumbers provide quick and reliable solutions for all your plumbing needs, from minor repairs to major installations.",
    features: [
      "Leak detection and repair",
      "Pipe installation and replacement",
      "Bathroom and kitchen fixture installation",
      "Water heater services and maintenance"
    ]
  },
  {
    id: 4,
    name: "Carpenter Services",
    slug: "carpenter",
    image: "https://images.unsplash.com/photo-1513467655676-561b7d489a88?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=350",
    description: "Custom carpentry work, furniture repair, and woodworking services.",
    detailImage: "https://images.unsplash.com/photo-1588854337115-1c67d9247e4d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=700&h=500",
    detailDescription: "From furniture assembly to custom woodwork, our carpentry services bring skill and precision to every project for your home.",
    features: [
      "Custom furniture design and creation",
      "Furniture repair and restoration",
      "Cabinet and shelving installation",
      "Door and window frame repairs"
    ]
  }
];

// Property data
export const properties = [
  {
    id: 1,
    title: "Prestige Lakeside Habitat",
    location: "Whitefield, East Bangalore",
    city: "Bangalore",
    price: 8550000,
    pricePerSqFt: 8550,
    size: 1250,
    bedrooms: 3,
    status: "Ready to Move",
    isRERAApproved: true,
    isPremium: true,
    isFeatured: false,
    image: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
    propertyType: "Apartments"
  },
  {
    id: 2,
    title: "Brigade Panorama",
    location: "Sector 62, Gurgaon",
    city: "Delhi NCR",
    price: 12000000,
    pricePerSqFt: 9230,
    size: 1850,
    bedrooms: 4,
    status: "Ready to Move",
    isRERAApproved: true,
    isPremium: false,
    isFeatured: false,
    image: "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
    propertyType: "Apartments"
  },
  {
    id: 3,
    title: "Godrej Woods",
    location: "Sector 43, Noida",
    city: "Delhi NCR",
    price: 24000000,
    pricePerSqFt: 9600,
    size: 2500,
    bedrooms: 4,
    status: "Under Construction",
    isRERAApproved: true,
    isPremium: false,
    isFeatured: true,
    image: "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
    propertyType: "Houses & Villas"
  },
  {
    id: 4,
    title: "DLF The Camellias",
    location: "Golf Course Road, Gurgaon",
    city: "Delhi NCR",
    price: 40000000,
    pricePerSqFt: 20000,
    size: 2000,
    bedrooms: 3,
    status: "Ready to Move",
    isRERAApproved: true,
    isPremium: true,
    isFeatured: false,
    image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
    propertyType: "Apartments"
  },
  {
    id: 5,
    title: "Hiranandani Gardens",
    location: "Powai, Mumbai",
    city: "Mumbai",
    price: 35000000,
    pricePerSqFt: 17500,
    size: 2200,
    bedrooms: 4,
    status: "Ready to Move",
    isRERAApproved: true,
    isPremium: false,
    isFeatured: true,
    image: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
    propertyType: "Houses & Villas"
  },
  {
    id: 6,
    title: "Sobha City",
    location: "Sector 108, Gurgaon",
    city: "Delhi NCR",
    price: 17500000,
    pricePerSqFt: 12500,
    size: 1400,
    bedrooms: 3,
    status: "Under Construction",
    isRERAApproved: true,
    isPremium: false,
    isFeatured: true,
    image: "https://images.unsplash.com/photo-1580216143794-b3b7d2a2d554?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
    propertyType: "Apartments"
  },
];

// Testimonial data
export const testimonials = [
  {
    id: 1,
    name: "Rahul Kumar",
    location: "Delhi",
    initials: "RK",
    color: "primary",
    rating: 5,
    content: "Found my dream apartment through PropertyAdda. The process was smooth and the platform provided all the information I needed to make a decision."
  },
  {
    id: 2,
    name: "Sneha Patel",
    location: "Bangalore",
    initials: "SP",
    color: "secondary",
    rating: 4.5,
    content: "The painting service I booked through PropertyAdda was excellent. Professional team, quality work, and they finished within the promised timeline."
  },
  {
    id: 3,
    name: "Aditya Mehta",
    location: "Mumbai",
    initials: "AM",
    color: "accent",
    rating: 5,
    content: "Sold my property faster than expected through PropertyAdda. The listing process was straightforward and I got multiple inquiries within days."
  },
];

// Property types
export const propertyTypes = [
  { id: 1, name: "All" },
  { id: 2, name: "Apartments" },
  { id: 3, name: "Houses & Villas" },
  { id: 4, name: "Builder Floors" },
  { id: 5, name: "Farmhouses" },
  { id: 6, name: "Plots" },
];

// Navigation links
export const navLinks = [
  { id: 1, name: "Buy", path: "/properties?type=buy" },
  { id: 2, name: "Rent", path: "/properties?type=rent" },
  { id: 3, name: "Sell", path: "/properties?type=sell" },
  { id: 4, name: "Home Services", path: "/services", active: true },
  { id: 5, name: "PG/Co-living", path: "/properties?type=pg" },
  { id: 6, name: "Plot", path: "/properties?type=plot" },
  { id: 7, name: "Commercial", path: "/properties?type=commercial" },
];

// Footer links
export const footerLinks = {
  company: [
    { name: "About Us", path: "/about" },
    { name: "Careers", path: "/careers" },
    { name: "Contact Us", path: "/contact" },
    { name: "Terms & Conditions", path: "/terms" },
    { name: "Privacy Policy", path: "/privacy" },
    { name: "Testimonials", path: "/testimonials" },
    { name: "Sitemap", path: "/sitemap" },
  ],
  propertyServices: [
    { name: "Buy Property", path: "/properties?type=buy" },
    { name: "Sell Property", path: "/properties?type=sell" },
    { name: "Rent Property", path: "/properties?type=rent" },
    { name: "PG & Co-living", path: "/properties?type=pg" },
    { name: "New Projects", path: "/properties?type=new" },
    { name: "Commercial Properties", path: "/properties?type=commercial" },
    { name: "Advertise Property", path: "/advertise" },
  ],
  homeServices: [
    { name: "Painting Services", path: "/services/painting" },
    { name: "Electrician Services", path: "/services/electrician" },
    { name: "Plumbing Services", path: "/services/plumbing" },
    { name: "Carpenter Services", path: "/services/carpenter" },
    { name: "Cleaning Services", path: "/services/cleaning" },
    { name: "Pest Control", path: "/services/pest-control" },
    { name: "Interior Design", path: "/services/interior-design" },
  ],
  socialMedia: [
    { name: "Facebook", icon: "fab fa-facebook-f", path: "https://facebook.com" },
    { name: "Twitter", icon: "fab fa-twitter", path: "https://twitter.com" },
    { name: "Instagram", icon: "fab fa-instagram", path: "https://instagram.com" },
    { name: "LinkedIn", icon: "fab fa-linkedin-in", path: "https://linkedin.com" },
    { name: "YouTube", icon: "fab fa-youtube", path: "https://youtube.com" },
  ]
};
