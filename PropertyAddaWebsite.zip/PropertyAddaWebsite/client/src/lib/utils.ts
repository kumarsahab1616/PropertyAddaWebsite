import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Format price to Indian currency format (e.g., ₹85.5 Lac, ₹1.2 Cr)
 */
export function formatIndianRupees(amount: number): string {
  if (amount >= 10000000) {
    // Convert to crores
    const crores = (amount / 10000000).toFixed(1);
    return `₹${crores} Cr`;
  } else if (amount >= 100000) {
    // Convert to lakhs
    const lakhs = (amount / 100000).toFixed(1);
    return `₹${lakhs} Lac`;
  } else {
    // Format as regular number
    return `₹${amount.toLocaleString()}`;
  }
}

/**
 * Format date to readable string
 */
export function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });
}

/**
 * Truncate text to a specified length
 */
export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return `${text.substring(0, maxLength)}...`;
}

/**
 * Validate email format
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Validate phone number (10 digits)
 */
export function isValidPhone(phone: string): boolean {
  const phoneRegex = /^\d{10}$/;
  return phoneRegex.test(phone);
}

/**
 * Parse URL query parameters
 */
export function parseQueryParams(url: string): Record<string, string> {
  const params: Record<string, string> = {};
  if (!url.includes('?')) return params;
  
  const queryString = url.split('?')[1];
  const urlParams = new URLSearchParams(queryString);
  
  urlParams.forEach((value, key) => {
    params[key] = value;
  });
  
  return params;
}
