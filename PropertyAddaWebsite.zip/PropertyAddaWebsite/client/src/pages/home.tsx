import { useState } from "react";
import { Link } from "wouter";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { HeroSection } from "@/components/home/hero-section";
import { ServiceCard } from "@/components/home/service-card";
import { PropertyCard } from "@/components/home/property-card";
import { LocationCard } from "@/components/home/location-card";
import { TestimonialCard } from "@/components/home/testimonial-card";
import { EnquiryForm } from "@/components/shared/enquiry-form";
import { 
  services, 
  properties, 
  propertyTypes, 
  locations, 
  testimonials 
} from "@/lib/data";

export default function Home() {
  const [activePropertyType, setActivePropertyType] = useState("Apartments");

  const filteredProperties = activePropertyType === "All" 
    ? properties 
    : properties.filter(property => property.propertyType === activePropertyType);

  return (
    <>
      <Header />
      
      <main>
        <HeroSection />
        
        {/* Services Banner */}
        <section className="py-8 bg-white">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-semibold font-poppins">Home Services</h2>
              <Link href="/services" className="text-primary font-medium text-sm hover:underline">
                View All Services
              </Link>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {services.map((service) => (
                <ServiceCard
                  key={service.id}
                  id={service.id}
                  name={service.name}
                  slug={service.slug}
                  image={service.image}
                  description={service.description}
                />
              ))}
            </div>
          </div>
        </section>
        
        {/* Featured Properties */}
        <section className="py-8 bg-neutral-light">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-semibold font-poppins">Featured Properties</h2>
              <Link href="/properties" className="text-primary font-medium text-sm hover:underline">
                View All Properties
              </Link>
            </div>
            
            {/* Quick filters */}
            <div className="flex flex-wrap gap-2 mb-6 overflow-x-auto pb-2">
              {propertyTypes.map((type) => (
                <button
                  key={type.id}
                  className={`${
                    activePropertyType === type.name
                      ? "bg-primary text-white"
                      : "bg-white border border-neutral-medium hover:border-primary hover:text-primary"
                  } px-4 py-2 rounded-full text-sm font-medium transition`}
                  onClick={() => setActivePropertyType(type.name)}
                >
                  {type.name}
                </button>
              ))}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProperties.slice(0, 3).map((property) => (
                <PropertyCard
                  key={property.id}
                  id={property.id}
                  title={property.title}
                  location={property.location}
                  price={property.price}
                  pricePerSqFt={property.pricePerSqFt}
                  size={property.size}
                  bedrooms={property.bedrooms}
                  status={property.status}
                  isRERAApproved={property.isRERAApproved}
                  isPremium={property.isPremium}
                  isFeatured={property.isFeatured}
                  image={property.image}
                />
              ))}
            </div>
          </div>
        </section>
        
        {/* Service Detail Section */}
        <section className="py-12 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-10">
              <h2 className="text-2xl md:text-3xl font-bold font-poppins mb-3">
                Professional Home Services
              </h2>
              <p className="text-neutral-dark max-w-2xl mx-auto">
                Get trusted professionals for all your home maintenance and improvement needs with PropertyAdda's verified service providers.
              </p>
            </div>
            
            {/* Painting Service */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center mb-12">
              <div>
                <h3 className="text-xl font-semibold font-poppins mb-4">Painting Services</h3>
                <p className="text-neutral-dark mb-4">
                  Transform your home with our professional painting services. Our expert painters use quality materials and techniques to deliver perfect finishes.
                </p>
                <ul className="mb-6 space-y-2">
                  {services[0].features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <i className="fas fa-check-circle text-secondary mt-1 mr-2"></i>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <Link 
                  href="/services/painting" 
                  className="inline-block bg-primary text-white font-medium py-3 px-6 rounded hover:bg-primary-dark transition"
                >
                  Book Painting Service
                </Link>
              </div>
              <div className="rounded-lg overflow-hidden shadow-lg">
                <img 
                  src={services[0].detailImage} 
                  alt="Professional Painting Service" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            
            {/* Electrician Service */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center mb-12">
              <div className="rounded-lg overflow-hidden shadow-lg order-2 lg:order-1">
                <img 
                  src={services[1].detailImage} 
                  alt="Professional Electrician Service" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="order-1 lg:order-2">
                <h3 className="text-xl font-semibold font-poppins mb-4">Electrician Services</h3>
                <p className="text-neutral-dark mb-4">
                  Our certified electricians provide complete electrical solutions for your home, ensuring safety and efficiency in every job.
                </p>
                <ul className="mb-6 space-y-2">
                  {services[1].features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <i className="fas fa-check-circle text-secondary mt-1 mr-2"></i>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <Link 
                  href="/services/electrician" 
                  className="inline-block bg-primary text-white font-medium py-3 px-6 rounded hover:bg-primary-dark transition"
                >
                  Book Electrician Service
                </Link>
              </div>
            </div>
          </div>
        </section>
        
        {/* Location Section */}
        <section className="py-8 bg-neutral-light">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-semibold font-poppins">Browse by Location</h2>
              <Link href="/properties" className="text-primary font-medium text-sm hover:underline">
                View All Locations
              </Link>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {locations.map((location) => (
                <LocationCard
                  key={location.id}
                  name={location.name}
                  propertyCount={location.propertyCount}
                  cityName={location.city}
                />
              ))}
            </div>
          </div>
        </section>
        
        {/* Testimonials */}
        <section className="py-12 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-10">
              <h2 className="text-2xl md:text-3xl font-bold font-poppins mb-3">
                What Our Customers Say
              </h2>
              <p className="text-neutral-dark max-w-2xl mx-auto">
                Hear from homeowners who found their perfect property and quality services with PropertyAdda.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {testimonials.map((testimonial) => (
                <TestimonialCard
                  key={testimonial.id}
                  name={testimonial.name}
                  location={testimonial.location}
                  initials={testimonial.initials}
                  color={testimonial.color}
                  rating={testimonial.rating}
                  content={testimonial.content}
                />
              ))}
            </div>
          </div>
        </section>
        
        {/* App Download */}
        <section className="py-12 bg-neutral-dark text-white">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-2xl md:text-3xl font-bold font-poppins mb-4">
                  Download the PropertyAdda App
                </h2>
                <p className="mb-6">
                  Get real-time notifications, save searches, and browse properties on the go with our mobile app.
                </p>
                <div className="flex flex-wrap gap-4">
                  <a href="#" className="inline-block">
                    <img 
                      src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg" 
                      alt="Get it on Google Play" 
                      className="h-12" 
                    />
                  </a>
                  <a href="#" className="inline-block">
                    <img 
                      src="https://upload.wikimedia.org/wikipedia/commons/3/3c/Download_on_the_App_Store_Badge.svg" 
                      alt="Download on the App Store" 
                      className="h-12" 
                    />
                  </a>
                </div>
              </div>
              <div className="flex justify-center">
                <img 
                  src="https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=600" 
                  alt="PropertyAdda Mobile App" 
                  className="max-w-full h-auto rounded-lg shadow-lg" 
                />
              </div>
            </div>
          </div>
        </section>
        
        {/* Contact CTA */}
        <section className="py-16 px-4 bg-gradient-to-r from-primary to-secondary text-white">
          <div className="container mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold mb-6">
                  Looking for Your Dream Property?
                </h2>
                <p className="text-lg mb-8 opacity-90">
                  Our experts are ready to assist you in finding the perfect property that matches your requirements and budget. Fill out the form, and we'll get back to you within 24 hours.
                </p>
                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="bg-white bg-opacity-20 p-3 rounded-full">
                      <i className="fas fa-home text-white"></i>
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">Personalized Property Search</h3>
                      <p className="opacity-80">Get customized property recommendations based on your requirements</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-4">
                    <div className="bg-white bg-opacity-20 p-3 rounded-full">
                      <i className="fas fa-handshake text-white"></i>
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">Expert Guidance</h3>
                      <p className="opacity-80">Our property experts will guide you through the entire buying/selling process</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-4">
                    <div className="bg-white bg-opacity-20 p-3 rounded-full">
                      <i className="fas fa-bolt text-white"></i>
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">Fast Response</h3>
                      <p className="opacity-80">Get a call back from our team within 24 hours of submitting your enquiry</p>
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <EnquiryForm className="bg-white shadow-xl" />
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </>
  );
}
