import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { PropertyCard } from "@/components/home/property-card";
import { LocationCard } from "@/components/home/location-card";
import { properties, locations, propertyTypes, cities } from "@/lib/data";

export default function PropertiesPage() {
  const [location] = useLocation();
  const [activePropertyType, setActivePropertyType] = useState<string>("All");
  const [selectedCity, setSelectedCity] = useState<string>("All Cities");
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 50000000]);
  const [bedroomFilter, setBedroomFilter] = useState<string>("Any");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [sortBy, setSortBy] = useState<string>("relevance");
  
  useEffect(() => {
    // Parse query parameters from URL
    const params = new URLSearchParams(location.split('?')[1]);
    const typeParam = params.get('type');
    const cityParam = params.get('city');
    const queryParam = params.get('query');
    
    if (typeParam) {
      setActivePropertyType(typeParam === 'all' ? 'All' : propertyTypes.find(t => t.name.toLowerCase().includes(typeParam))?.name || 'All');
    }
    
    if (cityParam) {
      setSelectedCity(cities.find(c => c.name.toLowerCase() === cityParam.toLowerCase())?.name || 'All Cities');
    }
    
    if (queryParam) {
      setSearchQuery(queryParam);
    }
  }, [location]);
  
  // Filter properties based on selected filters
  const filteredProperties = properties.filter(property => {
    // Filter by property type
    if (activePropertyType !== "All" && property.propertyType !== activePropertyType) {
      return false;
    }
    
    // Filter by city
    if (selectedCity !== "All Cities" && property.city !== selectedCity) {
      return false;
    }
    
    // Filter by bedrooms
    if (bedroomFilter !== "Any" && property.bedrooms !== parseInt(bedroomFilter)) {
      return false;
    }
    
    // Filter by price range
    if (property.price < priceRange[0] || property.price > priceRange[1]) {
      return false;
    }
    
    // Filter by search query
    if (searchQuery && !property.title.toLowerCase().includes(searchQuery.toLowerCase()) && 
        !property.location.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    
    return true;
  });
  
  // Sort properties
  const sortedProperties = [...filteredProperties].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return a.price - b.price;
      case "price-high":
        return b.price - a.price;
      case "newest":
        // In a real app, you would sort by creation date
        return b.id - a.id;
      default:
        // Sort by relevance (Featured/Premium properties first)
        if (a.isPremium && !b.isPremium) return -1;
        if (!a.isPremium && b.isPremium) return 1;
        if (a.isFeatured && !b.isFeatured) return -1;
        if (!a.isFeatured && b.isFeatured) return 1;
        return 0;
    }
  });
  
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // The properties are already filtered based on searchQuery state
  };
  
  const handleReset = () => {
    setActivePropertyType("All");
    setSelectedCity("All Cities");
    setPriceRange([0, 50000000]);
    setBedroomFilter("Any");
    setSearchQuery("");
    setSortBy("relevance");
  };

  return (
    <>
      <Header />
      
      <main>
        {/* Page Header */}
        <section className="bg-neutral-dark text-white py-8">
          <div className="container mx-auto px-4">
            <h1 className="text-2xl md:text-3xl font-bold font-poppins">Find Your Perfect Property</h1>
            <p className="text-lg">Browse our curated selection of premium properties</p>
          </div>
        </section>
        
        {/* Search Bar */}
        <section className="bg-white py-4 shadow-md">
          <div className="container mx-auto px-4">
            <form onSubmit={handleSearchSubmit} className="flex flex-col md:flex-row gap-2">
              <div className="flex-1">
                <input 
                  type="text" 
                  placeholder="Search by locality, project, or landmark" 
                  className="w-full p-3 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <button 
                type="submit"
                className="bg-primary hover:bg-primary-dark text-white font-medium py-3 px-6 rounded-md transition"
              >
                <i className="fas fa-search mr-2"></i> Search
              </button>
            </form>
          </div>
        </section>
        
        {/* Filter and Results */}
        <section className="py-8 bg-neutral-light">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {/* Filter Column */}
              <div className="col-span-1 bg-white rounded-lg shadow p-4">
                <div className="mb-6">
                  <h3 className="text-lg font-semibold mb-3">Filters</h3>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-neutral-dark">Results: {sortedProperties.length}</span>
                    <button 
                      onClick={handleReset}
                      className="text-sm text-primary hover:underline"
                    >
                      Reset All
                    </button>
                  </div>
                </div>
                
                {/* Property Type Filter */}
                <div className="mb-6">
                  <h4 className="font-medium mb-2">Property Type</h4>
                  <div className="flex flex-wrap gap-2">
                    {propertyTypes.map((type) => (
                      <button
                        key={type.id}
                        className={`${
                          activePropertyType === type.name
                            ? "bg-primary text-white"
                            : "bg-neutral-light hover:border-primary hover:text-primary"
                        } px-3 py-1 rounded-full text-xs font-medium transition`}
                        onClick={() => setActivePropertyType(type.name)}
                      >
                        {type.name}
                      </button>
                    ))}
                  </div>
                </div>
                
                {/* City Filter */}
                <div className="mb-6">
                  <h4 className="font-medium mb-2">City</h4>
                  <select
                    className="w-full p-2 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none bg-white"
                    value={selectedCity}
                    onChange={(e) => setSelectedCity(e.target.value)}
                  >
                    <option value="All Cities">All Cities</option>
                    {cities.map((city) => (
                      <option key={city.id} value={city.name}>{city.name}</option>
                    ))}
                  </select>
                </div>
                
                {/* Bedroom Filter */}
                <div className="mb-6">
                  <h4 className="font-medium mb-2">Bedrooms</h4>
                  <div className="flex space-x-2">
                    <button
                      className={`${
                        bedroomFilter === "Any"
                          ? "bg-primary text-white"
                          : "bg-neutral-light hover:border-primary hover:text-primary"
                      } px-3 py-1 rounded-md text-xs font-medium transition w-12`}
                      onClick={() => setBedroomFilter("Any")}
                    >
                      Any
                    </button>
                    {[1, 2, 3, 4, 5].map((num) => (
                      <button
                        key={num}
                        className={`${
                          bedroomFilter === num.toString()
                            ? "bg-primary text-white"
                            : "bg-neutral-light hover:border-primary hover:text-primary"
                        } px-3 py-1 rounded-md text-xs font-medium transition w-12`}
                        onClick={() => setBedroomFilter(num.toString())}
                      >
                        {num} BHK
                      </button>
                    ))}
                  </div>
                </div>
                
                {/* Price Range Filter */}
                <div className="mb-6">
                  <h4 className="font-medium mb-2">Price Range (₹)</h4>
                  <div className="flex justify-between text-sm mb-1">
                    <span>{(priceRange[0]/100000).toFixed(1)} Lac</span>
                    <span>{priceRange[1] >= 10000000 ? `${(priceRange[1]/10000000).toFixed(1)} Cr` : `${(priceRange[1]/100000).toFixed(1)} Lac`}</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="50000000"
                    step="500000"
                    className="w-full h-2 bg-neutral-medium rounded-lg appearance-none cursor-pointer accent-primary"
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                  />
                  <div className="flex justify-between mt-4">
                    <input
                      type="number"
                      className="w-24 p-2 border border-neutral-medium rounded-md text-sm"
                      value={priceRange[0]/100000}
                      onChange={(e) => setPriceRange([parseInt(e.target.value) * 100000, priceRange[1]])}
                      min="0"
                      max={priceRange[1]/100000}
                      step="1"
                    />
                    <span className="self-center">to</span>
                    <input
                      type="number"
                      className="w-24 p-2 border border-neutral-medium rounded-md text-sm"
                      value={priceRange[1]/100000}
                      onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value) * 100000])}
                      min={priceRange[0]/100000}
                      max="500"
                      step="1"
                    />
                  </div>
                </div>
              </div>
              
              {/* Results Column */}
              <div className="col-span-1 md:col-span-3">
                {/* Sort By */}
                <div className="bg-white rounded-lg shadow p-4 mb-6">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                    <h3 className="text-lg font-semibold">{sortedProperties.length} Properties Found</h3>
                    <div className="flex items-center">
                      <span className="text-sm mr-2">Sort By:</span>
                      <select
                        className="p-2 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none bg-white"
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value)}
                      >
                        <option value="relevance">Relevance</option>
                        <option value="price-low">Price: Low to High</option>
                        <option value="price-high">Price: High to Low</option>
                        <option value="newest">Newest First</option>
                      </select>
                    </div>
                  </div>
                </div>
                
                {/* Property Listings */}
                {sortedProperties.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {sortedProperties.map((property) => (
                      <PropertyCard
                        key={property.id}
                        id={property.id}
                        title={property.title}
                        location={property.location}
                        price={property.price}
                        pricePerSqFt={property.pricePerSqFt}
                        size={property.size}
                        bedrooms={property.bedrooms}
                        status={property.status}
                        isRERAApproved={property.isRERAApproved}
                        isPremium={property.isPremium}
                        isFeatured={property.isFeatured}
                        image={property.image}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="bg-white rounded-lg shadow p-8 text-center">
                    <i className="fas fa-search text-4xl text-neutral-medium mb-4"></i>
                    <h3 className="text-xl font-semibold mb-2">No Properties Found</h3>
                    <p className="text-neutral-dark mb-4">
                      We couldn't find any properties matching your search criteria. Try adjusting your filters.
                    </p>
                    <button 
                      onClick={handleReset}
                      className="bg-primary hover:bg-primary-dark text-white font-medium py-2 px-6 rounded-md transition"
                    >
                      Reset Filters
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>
        
        {/* Popular Locations */}
        <section className="py-8 bg-white">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-semibold font-poppins">Popular Locations</h2>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {locations.map((location) => (
                <LocationCard
                  key={location.id}
                  name={location.name}
                  propertyCount={location.propertyCount}
                  cityName={location.city}
                />
              ))}
            </div>
          </div>
        </section>
        
        {/* Contact Section */}
        <section className="py-12 bg-neutral-light">
          <div className="container mx-auto px-4">
            <div className="bg-white rounded-lg shadow-md p-8 max-w-4xl mx-auto">
              <div className="text-center mb-8">
                <h2 className="text-2xl font-bold font-poppins mb-3">Need Help Finding Your Perfect Property?</h2>
                <p className="text-neutral-dark">Our property experts are here to help you find the ideal home.</p>
              </div>
              
              <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
                <button className="bg-primary hover:bg-primary-dark text-white font-medium py-3 px-6 rounded-md transition flex items-center justify-center">
                  <i className="fas fa-phone-alt mr-2"></i> Call Us
                </button>
                <button className="bg-secondary hover:bg-secondary-dark text-white font-medium py-3 px-6 rounded-md transition flex items-center justify-center">
                  <i className="fas fa-envelope mr-2"></i> Email Us
                </button>
                <button className="bg-accent hover:bg-accent-dark text-white font-medium py-3 px-6 rounded-md transition flex items-center justify-center">
                  <i className="fab fa-whatsapp mr-2"></i> WhatsApp
                </button>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </>
  );
}
