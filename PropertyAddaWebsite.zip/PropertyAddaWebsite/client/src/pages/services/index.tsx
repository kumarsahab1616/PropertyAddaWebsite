import { useState } from "react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { ServiceCard } from "@/components/home/service-card";
import { services } from "@/lib/data";

export default function ServicesPage() {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [serviceType, setServiceType] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, you would submit the form to an API
    console.log("Service request submission:", { name, email, phone, serviceType, message });
    // Reset form
    setName("");
    setEmail("");
    setPhone("");
    setServiceType("");
    setMessage("");
    // Show success message
    alert("Thank you for your service request! Our team will contact you shortly.");
  };

  return (
    <>
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="bg-neutral-dark text-white py-12">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl">
              <h1 className="text-3xl md:text-4xl font-bold mb-4 font-poppins">
                Home Services
              </h1>
              <p className="text-lg mb-6">
                Find reliable professionals for all your home service needs
              </p>
            </div>
          </div>
        </section>
        
        {/* Services Section */}
        <section className="py-12 bg-neutral-light">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {services.map((service) => (
                <ServiceCard
                  key={service.id}
                  id={service.id}
                  name={service.name}
                  slug={service.slug}
                  image={service.image}
                  description={service.description}
                />
              ))}
            </div>
          </div>
        </section>
        
        {/* Service Process */}
        <section className="py-12 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-10">
              <h2 className="text-2xl md:text-3xl font-bold font-poppins mb-3">
                How It Works
              </h2>
              <p className="text-neutral-dark max-w-2xl mx-auto">
                Book a service in just a few simple steps
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                  1
                </div>
                <h3 className="text-lg font-semibold mb-2">Select a Service</h3>
                <p className="text-neutral-dark">
                  Choose from our wide range of professional home services
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                  2
                </div>
                <h3 className="text-lg font-semibold mb-2">Book an Appointment</h3>
                <p className="text-neutral-dark">
                  Select your preferred date and time for the service
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                  3
                </div>
                <h3 className="text-lg font-semibold mb-2">Get it Done</h3>
                <p className="text-neutral-dark">
                  Our professional will arrive and complete the service
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Request Form */}
        <section className="py-12 bg-neutral-light">
          <div className="container mx-auto px-4">
            <div className="bg-white rounded-lg shadow-md p-8 max-w-4xl mx-auto">
              <div className="text-center mb-8">
                <h2 className="text-2xl font-bold font-poppins mb-3">
                  Request a Service
                </h2>
                <p className="text-neutral-dark">
                  Fill out the form below and our service team will get in touch with you shortly
                </p>
              </div>
              
              <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-neutral-dark mb-1">
                    Name
                  </label>
                  <input 
                    type="text" 
                    id="name" 
                    className="w-full p-3 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none" 
                    placeholder="Your Name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-neutral-dark mb-1">
                    Email
                  </label>
                  <input 
                    type="email" 
                    id="email" 
                    className="w-full p-3 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none" 
                    placeholder="Your Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-neutral-dark mb-1">
                    Phone
                  </label>
                  <input 
                    type="tel" 
                    id="phone" 
                    className="w-full p-3 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none" 
                    placeholder="Your Phone Number"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="service-type" className="block text-sm font-medium text-neutral-dark mb-1">
                    Service Type
                  </label>
                  <select 
                    id="service-type" 
                    className="w-full p-3 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none bg-white"
                    value={serviceType}
                    onChange={(e) => setServiceType(e.target.value)}
                    required
                  >
                    <option value="">Select Service Type</option>
                    {services.map((service) => (
                      <option key={service.id} value={service.slug}>
                        {service.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className="md:col-span-2">
                  <label htmlFor="message" className="block text-sm font-medium text-neutral-dark mb-1">
                    Service Details
                  </label>
                  <textarea 
                    id="message" 
                    rows={4} 
                    className="w-full p-3 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none" 
                    placeholder="Please provide details about your service requirements"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    required
                  ></textarea>
                </div>
                
                <div className="md:col-span-2 text-center">
                  <button 
                    type="submit" 
                    className="bg-primary hover:bg-primary-dark text-white font-medium py-3 px-8 rounded-md transition"
                  >
                    Submit Request
                  </button>
                </div>
              </form>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </>
  );
}
