import { useState } from "react";
import { Link } from "wouter";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { services } from "@/lib/data";

// Get the plumbing service data
const plumbingService = services.find(service => service.slug === "plumbing");

export default function PlumbingServicePage() {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [propertyType, setPropertyType] = useState("");
  const [serviceType, setServiceType] = useState("");
  const [date, setDate] = useState("");
  const [address, setAddress] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, you would submit the form to an API
    console.log("Plumbing service request:", { 
      name, 
      email, 
      phone, 
      propertyType, 
      serviceType, 
      date, 
      address, 
      message 
    });
    // Reset form
    setName("");
    setEmail("");
    setPhone("");
    setPropertyType("");
    setServiceType("");
    setDate("");
    setAddress("");
    setMessage("");
    // Show success message
    alert("Thank you for your plumbing service request! Our team will contact you shortly.");
  };

  if (!plumbingService) {
    return <div>Service not found</div>;
  }

  return (
    <>
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="bg-neutral-dark text-white py-12">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl">
              <h1 className="text-3xl md:text-4xl font-bold mb-4 font-poppins">
                Professional Plumbing Services
              </h1>
              <p className="text-lg mb-6">
                Expert plumbing solutions for your home and business
              </p>
            </div>
          </div>
        </section>
        
        {/* Service Details */}
        <section className="py-12 bg-white">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center mb-12">
              <div>
                <h2 className="text-2xl font-semibold font-poppins mb-4">
                  Reliable Plumbing Services
                </h2>
                <p className="text-neutral-dark mb-6">
                  {plumbingService.detailDescription}
                </p>
                <div className="bg-neutral-light p-4 rounded-lg mb-6">
                  <h3 className="font-semibold mb-2">Our Plumbing Services Include:</h3>
                  <ul className="space-y-2">
                    {plumbingService.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <i className="fas fa-check-circle text-secondary mt-1 mr-2"></i>
                        <span>{feature}</span>
                      </li>
                    ))}
                    <li className="flex items-start">
                      <i className="fas fa-check-circle text-secondary mt-1 mr-2"></i>
                      <span>Drain cleaning and maintenance</span>
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-check-circle text-secondary mt-1 mr-2"></i>
                      <span>Preventative maintenance plans</span>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="rounded-lg overflow-hidden shadow-lg">
                <img 
                  src={plumbingService.detailImage} 
                  alt="Professional Plumbing Service" 
                  className="w-full h-full object-cover" 
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              <div className="bg-neutral-light p-6 rounded-lg">
                <div className="w-12 h-12 bg-primary text-white rounded-full flex items-center justify-center text-xl mb-4">
                  <i className="fas fa-wrench"></i>
                </div>
                <h3 className="text-lg font-semibold mb-2">Repairs & Maintenance</h3>
                <p className="text-neutral-dark">
                  Fast and effective solutions for leaks, clogs, and other plumbing issues. We ensure long-lasting repairs.
                </p>
              </div>
              
              <div className="bg-neutral-light p-6 rounded-lg">
                <div className="w-12 h-12 bg-primary text-white rounded-full flex items-center justify-center text-xl mb-4">
                  <i className="fas fa-shower"></i>
                </div>
                <h3 className="text-lg font-semibold mb-2">Installation Services</h3>
                <p className="text-neutral-dark">
                  Professional installation of sinks, toilets, faucets, showers, and complete bathroom renovations.
                </p>
              </div>
              
              <div className="bg-neutral-light p-6 rounded-lg">
                <div className="w-12 h-12 bg-primary text-white rounded-full flex items-center justify-center text-xl mb-4">
                  <i className="fas fa-tint"></i>
                </div>
                <h3 className="text-lg font-semibold mb-2">Water Systems</h3>
                <p className="text-neutral-dark">
                  Water heater services, water filtration systems, and water pressure solutions for your home.
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Why Choose Us */}
        <section className="py-12 bg-neutral-light">
          <div className="container mx-auto px-4">
            <div className="text-center mb-10">
              <h2 className="text-2xl font-bold font-poppins mb-3">
                Why Choose Our Plumbing Services
              </h2>
              <p className="text-neutral-dark max-w-2xl mx-auto">
                We deliver professional, reliable, and efficient plumbing solutions
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="text-primary text-3xl mb-4">
                  <i className="fas fa-user-tie"></i>
                </div>
                <h3 className="font-semibold mb-2">Licensed Professionals</h3>
                <p className="text-neutral-dark text-sm">
                  Our plumbers are fully licensed, insured, and experienced.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="text-primary text-3xl mb-4">
                  <i className="fas fa-clock"></i>
                </div>
                <h3 className="font-semibold mb-2">24/7 Emergency Service</h3>
                <p className="text-neutral-dark text-sm">
                  Round-the-clock emergency service for urgent plumbing problems.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="text-primary text-3xl mb-4">
                  <i className="fas fa-tools"></i>
                </div>
                <h3 className="font-semibold mb-2">Advanced Equipment</h3>
                <p className="text-neutral-dark text-sm">
                  We use the latest tools and technology for efficient and accurate service.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="text-primary text-3xl mb-4">
                  <i className="fas fa-hand-holding-usd"></i>
                </div>
                <h3 className="font-semibold mb-2">Transparent Pricing</h3>
                <p className="text-neutral-dark text-sm">
                  Upfront pricing with no hidden fees or surprise charges.
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Booking Form */}
        <section className="py-12 bg-white">
          <div className="container mx-auto px-4">
            <div className="bg-neutral-light rounded-lg p-8 max-w-4xl mx-auto">
              <div className="text-center mb-8">
                <h2 className="text-2xl font-bold font-poppins mb-3">
                  Book a Plumber
                </h2>
                <p className="text-neutral-dark">
                  Fill out the form below to schedule a plumbing service
                </p>
              </div>
              
              <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-neutral-dark mb-1">
                    Name
                  </label>
                  <input 
                    type="text" 
                    id="name" 
                    className="w-full p-3 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none" 
                    placeholder="Your Name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-neutral-dark mb-1">
                    Email
                  </label>
                  <input 
                    type="email" 
                    id="email" 
                    className="w-full p-3 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none" 
                    placeholder="Your Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-neutral-dark mb-1">
                    Phone
                  </label>
                  <input 
                    type="tel" 
                    id="phone" 
                    className="w-full p-3 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none" 
                    placeholder="Your Phone Number"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="property-type" className="block text-sm font-medium text-neutral-dark mb-1">
                    Property Type
                  </label>
                  <select 
                    id="property-type" 
                    className="w-full p-3 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none bg-white"
                    value={propertyType}
                    onChange={(e) => setPropertyType(e.target.value)}
                    required
                  >
                    <option value="">Select Property Type</option>
                    <option value="apartment">Apartment</option>
                    <option value="house">House</option>
                    <option value="villa">Villa</option>
                    <option value="office">Office</option>
                    <option value="commercial">Commercial</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="service-type" className="block text-sm font-medium text-neutral-dark mb-1">
                    Service Type
                  </label>
                  <select 
                    id="service-type" 
                    className="w-full p-3 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none bg-white"
                    value={serviceType}
                    onChange={(e) => setServiceType(e.target.value)}
                    required
                  >
                    <option value="">Select Service Type</option>
                    <option value="leak">Leak Repair</option>
                    <option value="installation">Fixture Installation</option>
                    <option value="clog">Drain Cleaning</option>
                    <option value="water-heater">Water Heater Service</option>
                    <option value="emergency">Emergency Service</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="date" className="block text-sm font-medium text-neutral-dark mb-1">
                    Preferred Date
                  </label>
                  <input 
                    type="date" 
                    id="date" 
                    className="w-full p-3 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none" 
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    required
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label htmlFor="address" className="block text-sm font-medium text-neutral-dark mb-1">
                    Address
                  </label>
                  <input 
                    type="text" 
                    id="address" 
                    className="w-full p-3 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none" 
                    placeholder="Your Complete Address"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    required
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label htmlFor="message" className="block text-sm font-medium text-neutral-dark mb-1">
                    Describe the Issue
                  </label>
                  <textarea 
                    id="message" 
                    rows={4} 
                    className="w-full p-3 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none" 
                    placeholder="Please describe the plumbing issue or service you need"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                  ></textarea>
                </div>
                
                <div className="md:col-span-2 text-center">
                  <button 
                    type="submit" 
                    className="bg-primary hover:bg-primary-dark text-white font-medium py-3 px-8 rounded-md transition"
                  >
                    Book Service
                  </button>
                </div>
              </form>
            </div>
          </div>
        </section>
        
        {/* Other Services */}
        <section className="py-12 bg-neutral-light">
          <div className="container mx-auto px-4">
            <div className="text-center mb-10">
              <h2 className="text-2xl font-bold font-poppins mb-3">
                Explore Other Services
              </h2>
              <p className="text-neutral-dark max-w-2xl mx-auto">
                Discover our complete range of home services
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {services.filter(service => service.slug !== "plumbing").map((service) => (
                <div key={service.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                  <div className="h-40 overflow-hidden">
                    <img 
                      src={service.image} 
                      alt={service.name} 
                      className="w-full h-full object-cover" 
                    />
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold text-lg mb-2">{service.name}</h3>
                    <p className="text-neutral-dark text-sm mb-3">{service.description}</p>
                    <Link 
                      href={`/services/${service.slug}`} 
                      className="inline-block bg-primary text-white font-medium py-2 px-4 rounded text-sm hover:bg-primary-dark transition"
                    >
                      View Details
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </>
  );
}
