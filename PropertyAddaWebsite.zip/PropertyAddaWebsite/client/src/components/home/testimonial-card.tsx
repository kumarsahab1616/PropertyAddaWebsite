import { useMemo } from "react";

interface TestimonialCardProps {
  name: string;
  location: string;
  initials: string;
  color: string;
  rating: number;
  content: string;
}

export function TestimonialCard({
  name,
  location,
  initials,
  color,
  rating,
  content,
}: TestimonialCardProps) {
  const colorClass = useMemo(() => {
    switch (color) {
      case "primary":
        return "bg-primary";
      case "secondary":
        return "bg-secondary";
      case "accent":
        return "bg-accent";
      default:
        return "bg-primary";
    }
  }, [color]);

  // Generate rating stars
  const renderStars = () => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    // Add full stars
    for (let i = 0; i < fullStars; i++) {
      stars.push(<i key={`full-${i}`} className="fas fa-star"></i>);
    }
    
    // Add half star if needed
    if (hasHalfStar) {
      stars.push(<i key="half" className="fas fa-star-half-alt"></i>);
    }
    
    // Add empty stars
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<i key={`empty-${i}`} className="far fa-star"></i>);
    }
    
    return stars;
  };

  return (
    <div className="bg-neutral-light rounded-lg p-6">
      <div className="flex items-center mb-4">
        <div className={`w-12 h-12 ${colorClass} text-white rounded-full flex items-center justify-center font-bold mr-3`}>
          {initials}
        </div>
        <div>
          <h4 className="font-medium">{name}</h4>
          <p className="text-sm text-neutral-dark">{location}</p>
        </div>
      </div>
      <div className="mb-3 text-yellow-400">
        {renderStars()}
      </div>
      <p className="text-neutral-dark">{content}</p>
    </div>
  );
}
