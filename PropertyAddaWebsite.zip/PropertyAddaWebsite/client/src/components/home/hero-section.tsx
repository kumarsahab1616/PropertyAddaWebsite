import { useState } from "react";
import { useLocation } from "wouter";

export function HeroSection() {
  const [searchType, setSearchType] = useState("buy");
  const [searchQuery, setSearchQuery] = useState("");
  const [_, setLocation] = useLocation();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setLocation(`/properties?type=${searchType}&query=${encodeURIComponent(searchQuery)}`);
  };

  const searchTypes = [
    { id: "buy", label: "Buy" },
    { id: "rent", label: "Rent" },
    { id: "pg", label: "PG/Co-living" },
    { id: "plot", label: "Plot" },
    { id: "commercial", label: "Commercial" },
  ];

  return (
    <section className="relative overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center" 
        style={{ 
          backgroundImage: "url('https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=800')",
          filter: "brightness(0.7)"
        }}
      ></div>
      
      <div className="relative container mx-auto px-4 py-16 md:py-24">
        <div className="max-w-3xl">
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4 font-poppins">
            Find Your Perfect Home & Professional Services
          </h1>
          <p className="text-white text-lg mb-6">
            Discover properties and home services tailored to your needs
          </p>
          
          {/* Search Box */}
          <div className="bg-white p-4 rounded-lg shadow-lg">
            <div className="flex flex-wrap mb-3">
              {searchTypes.map((type) => (
                <button 
                  key={type.id}
                  className={`px-4 py-2 font-medium text-sm ${
                    searchType === type.id 
                      ? "bg-primary text-white" 
                      : "bg-white text-neutral-dark"
                  } ${type.id === "buy" ? "rounded-l" : ""}`}
                  onClick={() => setSearchType(type.id)}
                >
                  {type.label}
                </button>
              ))}
            </div>
            
            <form onSubmit={handleSearch} className="flex flex-col md:flex-row gap-2">
              <div className="flex-1">
                <input 
                  type="text" 
                  placeholder="Search by locality, landmark, project, or builder" 
                  className="w-full p-3 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <button 
                type="submit"
                className="bg-primary hover:bg-primary-dark text-white font-medium py-3 px-6 rounded-md transition"
              >
                <i className="fas fa-search mr-2"></i> Search
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
