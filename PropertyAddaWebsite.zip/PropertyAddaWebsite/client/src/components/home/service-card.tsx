import { Link } from "wouter";

interface ServiceCardProps {
  id: number;
  name: string;
  slug: string;
  image: string;
  description: string;
}

export function ServiceCard({ id, name, slug, image, description }: ServiceCardProps) {
  return (
    <div className="service-card bg-white rounded-lg shadow-md overflow-hidden transition duration-300">
      <div className="h-48 overflow-hidden">
        <img src={image} alt={name} className="w-full h-full object-cover" />
      </div>
      <div className="p-4">
        <h3 className="font-semibold text-lg mb-2">{name}</h3>
        <p className="text-neutral-dark text-sm mb-3">{description}</p>
        <Link 
          href={`/services/${slug}`} 
          className="inline-block bg-primary text-white font-medium py-2 px-4 rounded text-sm hover:bg-primary-dark transition"
        >
          Book Now
        </Link>
      </div>
    </div>
  );
}
