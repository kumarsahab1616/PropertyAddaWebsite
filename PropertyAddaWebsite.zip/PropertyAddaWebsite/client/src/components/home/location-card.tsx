import { Link } from "wouter";

interface LocationCardProps {
  name: string;
  propertyCount: number;
  cityName?: string;
}

export function LocationCard({ name, propertyCount, cityName }: LocationCardProps) {
  const url = cityName 
    ? `/properties?city=${encodeURIComponent(cityName)}&location=${encodeURIComponent(name)}` 
    : `/properties?location=${encodeURIComponent(name)}`;
  
  return (
    <Link href={url} className="location-card bg-white rounded-lg shadow-sm p-4 text-center hover:shadow-md transition">
      <h3 className="font-medium text-neutral-dark">{name}</h3>
      <p className="text-sm text-neutral-dark">{propertyCount}+ Properties</p>
    </Link>
  );
}
