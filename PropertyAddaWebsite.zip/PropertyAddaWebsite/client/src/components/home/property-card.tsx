import { useState } from "react";
import { formatIndianRupees } from "@/lib/utils";

interface PropertyCardProps {
  id: number;
  title: string;
  location: string;
  price: number;
  pricePerSqFt: number;
  size: number;
  bedrooms: number;
  status: string;
  isRERAApproved: boolean;
  isPremium?: boolean;
  isFeatured?: boolean;
  image: string;
}

export function PropertyCard({
  id,
  title,
  location,
  price,
  pricePerSqFt,
  size,
  bedrooms,
  status,
  isRERAApproved,
  isPremium,
  isFeatured,
  image,
}: PropertyCardProps) {
  const [isFavorite, setIsFavorite] = useState(false);

  const toggleFavorite = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsFavorite(!isFavorite);
  };

  const contactOwner = (e: React.MouseEvent) => {
    e.preventDefault();
    alert(`Contact owner for property: ${title}`);
  };

  // Format price for display (e.g., ₹85.5 Lac, ₹1.2 Cr)
  const formattedPrice = formatIndianRupees(price);

  return (
    <div className="property-card bg-white rounded-lg shadow-md overflow-hidden transition duration-300">
      <div className="relative">
        <div className="h-56 overflow-hidden">
          <img src={image} alt={title} className="w-full h-full object-cover" />
        </div>
        
        {isPremium && (
          <span className="absolute top-3 left-3 bg-primary text-white px-2 py-1 text-xs font-medium rounded">
            PREMIUM
          </span>
        )}
        
        {isFeatured && (
          <span className="absolute top-3 left-3 bg-primary text-white px-2 py-1 text-xs font-medium rounded">
            FEATURED
          </span>
        )}
        
        <button
          className="absolute top-3 right-3 bg-white rounded-full p-2 shadow-md hover:text-primary"
          onClick={toggleFavorite}
        >
          <i className={isFavorite ? "fas fa-heart text-primary" : "far fa-heart"}></i>
        </button>
      </div>
      
      <div className="p-4">
        <div className="flex justify-between mb-2">
          <span className="text-primary font-semibold text-lg">{formattedPrice}</span>
          <span className="text-neutral-dark text-sm">₹{pricePerSqFt.toLocaleString()}/sq.ft</span>
        </div>
        
        <h3 className="font-semibold text-lg mb-1">{title}</h3>
        <p className="text-neutral-dark text-sm mb-2">{location}</p>
        
        <div className="flex text-sm text-neutral-dark mb-3">
          <div className="pr-3 mr-3 border-r border-neutral-medium">
            <span className="font-medium">{bedrooms}</span> BHK
          </div>
          <div className="pr-3 mr-3 border-r border-neutral-medium">
            <span className="font-medium">{size}</span> sq.ft
          </div>
          <div>
            <span className="font-medium">{status}</span>
          </div>
        </div>
        
        <div className="flex justify-between items-center">
          <div className="text-sm">
            {isRERAApproved && (
              <span className="bg-success bg-opacity-10 text-success px-2 py-1 rounded-sm">
                RERA Approved
              </span>
            )}
          </div>
          <button
            className="text-primary font-medium text-sm hover:underline"
            onClick={contactOwner}
          >
            Contact Owner
          </button>
        </div>
      </div>
    </div>
  );
}
