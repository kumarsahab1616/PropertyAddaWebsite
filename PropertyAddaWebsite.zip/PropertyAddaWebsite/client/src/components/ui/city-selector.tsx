import { useState, useRef, useEffect } from "react";
import { cities } from "@/lib/data";

interface CitySelectorProps {
  selectedCity: string;
  setSelectedCity: (city: string) => void;
}

export function CitySelector({ selectedCity, setSelectedCity }: CitySelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const handleCitySelect = (cityName: string) => {
    setSelectedCity(cityName);
    setIsOpen(false);
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div className="city-selector relative ml-6" ref={dropdownRef}>
      <button
        className="flex items-center text-neutral-dark hover:text-primary"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="font-semibold">{selectedCity}</span>
        <i className={`fas fa-chevron-${isOpen ? 'up' : 'down'} ml-2 text-xs`}></i>
      </button>
      
      {isOpen && (
        <div className="city-dropdown absolute mt-2 bg-white shadow-lg rounded-md w-72 p-4 z-50">
          <h4 className="text-sm font-semibold mb-2">Popular Cities</h4>
          <div className="grid grid-cols-3 gap-2">
            {cities.map((city) => (
              <button
                key={city.id}
                className="text-sm text-left hover:text-primary"
                onClick={() => handleCitySelect(city.name)}
              >
                {city.name}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
