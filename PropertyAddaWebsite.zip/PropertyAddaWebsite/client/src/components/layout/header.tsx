import { useState, useEffect, useRef } from "react";
import { Link, useLocation } from "wouter";
import { navLinks, cities } from "@/lib/data";

export function Header() {
  const [selectedCity, setSelectedCity] = useState("Delhi NCR");
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showCityDropdown, setShowCityDropdown] = useState(false);
  const cityDropdownRef = useRef<HTMLDivElement>(null);
  
  // Function to detect user's city (using a simple query parameter detection)
  useEffect(() => {
    const detectCity = () => {
      // Check if there's a city in the URL
      const cityParam = new URLSearchParams(window.location.search).get('city');
      if (cityParam) {
        const city = cities.find(c => c.slug === cityParam);
        if (city) {
          setSelectedCity(city.name);
        }
      } else {
        // In a real app, we might use geolocation or IP-based detection
        // For now, we're just using a default
        setSelectedCity("Delhi NCR");
      }
    };
    
    detectCity();
  }, [location]);
  
  // Close city dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (cityDropdownRef.current && !cityDropdownRef.current.contains(event.target as Node)) {
        setShowCityDropdown(false);
      }
    }
    
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [cityDropdownRef]);

  return (
    <header className="sticky top-0 z-50">
      {/* Top Bar */}
      <div className="bg-gradient-to-r from-primary to-secondary text-white py-1.5 px-4">
        <div className="container mx-auto flex justify-between items-center text-xs">
          <div className="flex space-x-4">
            <a href="#" className="hover:text-white hover:underline flex items-center">
              <i className="fas fa-mobile-alt mr-1"></i> Download App
            </a>
            <a href="#" className="hover:text-white hover:underline flex items-center">
              <i className="fas fa-briefcase mr-1"></i> PropertyAdda for Business
            </a>
            <a href="#" className="hover:text-white hover:underline hidden sm:flex items-center">
              <i className="fas fa-ad mr-1"></i> Advertise
            </a>
          </div>
          <div className="flex space-x-4">
            <a href="#" className="hover:text-white hover:underline hidden sm:flex items-center">
              <i className="fas fa-blog mr-1"></i> Blog
            </a>
            <a href="#" className="hover:text-white hover:underline flex items-center">
              <i className="fas fa-question-circle mr-1"></i> Help
            </a>
            <a href="#" className="hover:text-white hover:underline flex items-center">
              <i className="fas fa-envelope mr-1"></i> Contact Us
            </a>
          </div>
        </div>
      </div>
      
      {/* Main Header */}
      <div className="bg-white shadow-lg">
        <div className="container mx-auto py-3 px-4">
          {/* Logo and Auth Buttons */}
          <div className="flex flex-col md:flex-row justify-between items-center mb-2">
            <div className="flex items-center mb-3 md:mb-0">
              <Link href="/" className="flex items-center">
                <div className="relative">
                  <span className="text-3xl font-bold font-poppins bg-clip-text text-transparent bg-gradient-to-r from-primary via-secondary to-accent">
                    Property<span className="font-extrabold">Adda</span>
                  </span>
                  <div className="absolute -top-3 -right-6 bg-primary text-white text-xs px-1.5 py-0.5 rounded-sm transform rotate-12">
                    .com
                  </div>
                </div>
              </Link>
            </div>
            
            {/* Auth Buttons */}
            <div className="flex items-center space-x-3 mt-2 md:mt-0">
              <button className="text-sm font-medium px-4 py-2 border-2 border-primary text-primary rounded-md hover:bg-primary hover:text-white transition-all duration-300 flex items-center">
                <i className="fas fa-sign-in-alt mr-1.5"></i> Login
              </button>
              <button className="text-sm font-medium px-4 py-2 bg-gradient-to-r from-primary to-secondary text-white rounded-md hover:shadow-lg transition-all duration-300 flex items-center">
                <i className="fas fa-plus-circle mr-1.5"></i> Post Property <span className="hidden sm:inline ml-1">FREE</span>
              </button>
            </div>
          </div>
          
          {/* All India Cities - MagicBricks Style */}
          <div className="w-full border-t border-b border-neutral-medium py-2 overflow-x-auto mb-2">
            <div className="flex space-x-6 text-sm items-center">
              <div className="relative" ref={cityDropdownRef}>
                <button 
                  onClick={() => setShowCityDropdown(!showCityDropdown)} 
                  className="city-drop-heading--main location-icn flex items-center font-medium text-primary whitespace-nowrap ml-2"
                >
                  <i className="fas fa-map-marker-alt mr-1.5"></i> {selectedCity.toUpperCase()} <i className="fas fa-caret-down ml-1.5"></i>
                </button>
                
                {/* City Dropdown */}
                {showCityDropdown && (
                  <div className="absolute top-full left-0 mt-2 w-[280px] max-h-[480px] overflow-y-auto bg-white shadow-lg rounded-md border border-neutral-medium z-50 city-dropdown">
                    <div className="p-3 bg-neutral-light border-b border-neutral-medium">
                      <h3 className="font-semibold text-neutral-dark">Popular Cities</h3>
                    </div>
                    <div className="p-3 grid grid-cols-2 gap-2">
                      {cities.map((city) => (
                        <a 
                          key={city.id}
                          href={`/properties?city=${city.slug}`}
                          className={`text-sm py-1.5 px-2 rounded hover:bg-neutral-light flex items-center ${
                            selectedCity === city.name ? "text-primary font-medium" : "text-neutral-dark"
                          }`}
                          onClick={() => {
                            setSelectedCity(city.name);
                            setShowCityDropdown(false);
                          }}
                        >
                          {selectedCity === city.name && <i className="fas fa-check-circle mr-1.5 text-primary"></i>}
                          {city.name} <span className="text-xs text-neutral-dark ml-1">({city.propertyCount})</span>
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              
              <div className="flex space-x-5 overflow-x-auto pb-1">
                {cities.slice(0, 10).map((city) => (
                  <a 
                    key={city.id}
                    href={`/properties?city=${city.slug}`}
                    className={`city-drop-heading--main whitespace-nowrap transition-colors ${
                      selectedCity === city.name ? "text-primary font-medium" : "hover:text-primary"
                    }`}
                  >
                    {city.name}
                  </a>
                ))}
                <button 
                  onClick={() => setShowCityDropdown(!showCityDropdown)}
                  className="city-drop-heading--main whitespace-nowrap hover:text-primary transition-colors font-medium"
                >
                  + more
                </button>
              </div>
            </div>
          </div>
          
          {/* Mobile Menu Button */}
          <div className="md:hidden w-full flex justify-end -mt-14">
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)} 
              className="text-primary p-2 rounded-full hover:bg-neutral-light"
            >
              <i className={`fas fa-${mobileMenuOpen ? 'times' : 'bars'}`}></i>
            </button>
          </div>
          
          {/* Nav Links - Magicbricks style horizontal nav */}
          <div className={`${mobileMenuOpen ? 'block' : 'hidden'} md:block w-full border-t border-neutral-medium mt-2 pt-2`}>
            <div className="flex flex-col md:flex-row md:space-x-6 text-neutral-dark overflow-x-auto w-full pb-2 md:pb-0">
              {navLinks.map((link) => (
                <Link 
                  key={link.id}
                  href={link.path}
                  className={`whitespace-nowrap px-3 py-2 text-sm font-semibold transition-all duration-200 flex items-center ${
                    location === link.path || (link.active && location.includes(link.path)) 
                      ? "text-primary" 
                      : "text-neutral-dark hover:text-primary"
                  }`}
                >
                  {/* Adding icons to each nav link for more visual appeal */}
                  {link.name === "Buy" && <i className="fas fa-home mr-1.5"></i>}
                  {link.name === "Rent" && <i className="fas fa-key mr-1.5"></i>}
                  {link.name === "Sell" && <i className="fas fa-tag mr-1.5"></i>}
                  {link.name === "Home Services" && <i className="fas fa-tools mr-1.5"></i>}
                  {link.name === "PG/Co-living" && <i className="fas fa-users mr-1.5"></i>}
                  {link.name === "Plot" && <i className="fas fa-map-marked-alt mr-1.5"></i>}
                  {link.name === "Commercial" && <i className="fas fa-building mr-1.5"></i>}
                  {link.name}
                  {(location === link.path || (link.active && location.includes(link.path))) && (
                    <div className="absolute bottom-0 left-0 w-full h-0.5 bg-primary"></div>
                  )}
                </Link>
              ))}
            </div>
          </div>
          
          {/* Quick Action bar - like MagicBricks */}
          <div className="hidden lg:flex justify-between bg-neutral-light rounded-md px-4 py-2 mt-2">
            <div className="flex space-x-4 text-sm">
              <a href="#" className="flex items-center text-neutral-dark hover:text-primary">
                <i className="fas fa-calculator mr-1.5"></i> EMI Calculator
              </a>
              <a href="#" className="flex items-center text-neutral-dark hover:text-primary">
                <i className="fas fa-ruler-combined mr-1.5"></i> Area Converter
              </a>
              <a href="#" className="flex items-center text-neutral-dark hover:text-primary">
                <i className="fas fa-map-marked-alt mr-1.5"></i> Property Rates
              </a>
            </div>
            <div className="flex space-x-4 text-sm">
              <a href="#" className="flex items-center text-neutral-dark hover:text-primary">
                <i className="fas fa-chart-line mr-1.5"></i> Investment Advice
              </a>
              <a href="#" className="flex items-center text-neutral-dark hover:text-primary">
                <i className="fas fa-hands-helping mr-1.5"></i> Owner Services
              </a>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
