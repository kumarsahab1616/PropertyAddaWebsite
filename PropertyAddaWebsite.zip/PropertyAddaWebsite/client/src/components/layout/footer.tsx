import { Link } from "wouter";
import { footerLinks } from "@/lib/data";
import { useState } from "react";

export function Footer() {
  const [email, setEmail] = useState("");
  const year = new Date().getFullYear();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, you would submit the email to an API
    console.log("Newsletter subscription for:", email);
    setEmail("");
    // Show success message
    alert("Thank you for subscribing to our newsletter!");
  };

  return (
    <footer className="bg-[#1a1a1a] text-white">
      {/* Newsletter Banner - Like MagicBricks */}
      <div className="bg-gradient-to-r from-primary to-secondary py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0 text-center md:text-left">
              <h3 className="text-2xl font-bold">Stay Updated with Property Trends</h3>
              <p className="text-sm text-white text-opacity-90 mt-2">
                Get alerts on price drops, new properties and investment opportunities
              </p>
            </div>
            <div className="w-full md:w-auto">
              <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row">
                <input 
                  type="email" 
                  placeholder="Your Email Address" 
                  className="px-4 py-3 rounded-l-md border-none focus:outline-none w-full sm:w-64"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
                <button 
                  type="submit"
                  className="bg-accent hover:bg-accent-dark text-white font-semibold px-6 py-3 rounded-r-md transition-colors mt-2 sm:mt-0">
                  Subscribe
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
      
      {/* Download App Section - Like MagicBricks */}
      <div className="bg-black bg-opacity-40 py-8 border-b border-neutral-medium border-opacity-20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="mb-6 md:mb-0 flex flex-col sm:flex-row items-center">
              <div className="mr-0 sm:mr-6 mb-4 sm:mb-0">
                <div className="w-16 h-16 bg-white p-3 rounded-xl flex items-center justify-center mb-4 md:mb-0">
                  <i className="fas fa-mobile-alt text-primary text-3xl"></i>
                </div>
              </div>
              <div className="text-center sm:text-left">
                <h3 className="text-xl font-bold">Download PropertyAdda App</h3>
                <p className="text-sm text-white text-opacity-80 mt-1">
                  Search properties on the go with our top-rated mobile app
                </p>
              </div>
            </div>
            <div className="flex space-x-4">
              <a href="#" className="inline-block">
                <img 
                  src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg" 
                  alt="Get it on Google Play" 
                  className="h-10 sm:h-12" 
                />
              </a>
              <a href="#" className="inline-block">
                <img 
                  src="https://upload.wikimedia.org/wikipedia/commons/3/3c/Download_on_the_App_Store_Badge.svg" 
                  alt="Download on the App Store" 
                  className="h-10 sm:h-12" 
                />
              </a>
            </div>
          </div>
        </div>
      </div>
      
      {/* Main Footer Links - MagicBricks style */}
      <div className="container mx-auto py-12 px-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-x-6 gap-y-10">
          {/* PropertyAdda Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4 font-poppins relative">
              PropertyAdda
              <span className="absolute bottom-0 left-0 w-10 h-0.5 bg-primary"></span>
            </h3>
            <ul className="space-y-3">
              {footerLinks.company.map((link, index) => (
                <li key={index}>
                  <Link href={link.path} className="text-neutral-medium hover:text-primary transition flex items-center">
                    <i className="fas fa-chevron-right text-xs mr-2 text-primary"></i> {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Property Services */}
          <div>
            <h3 className="text-lg font-semibold mb-4 font-poppins relative">
              Property Services
              <span className="absolute bottom-0 left-0 w-10 h-0.5 bg-primary"></span>
            </h3>
            <ul className="space-y-3">
              {footerLinks.propertyServices.map((link, index) => (
                <li key={index}>
                  <Link href={link.path} className="text-neutral-medium hover:text-primary transition flex items-center">
                    <i className="fas fa-chevron-right text-xs mr-2 text-primary"></i> {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Home Services */}
          <div>
            <h3 className="text-lg font-semibold mb-4 font-poppins relative">
              Home Services
              <span className="absolute bottom-0 left-0 w-10 h-0.5 bg-primary"></span>
            </h3>
            <ul className="space-y-3">
              {footerLinks.homeServices.map((link, index) => (
                <li key={index}>
                  <Link href={link.path} className="text-neutral-medium hover:text-primary transition flex items-center">
                    <i className="fas fa-chevron-right text-xs mr-2 text-primary"></i> {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Popular Locations */}
          <div>
            <h3 className="text-lg font-semibold mb-4 font-poppins relative">
              Popular Cities
              <span className="absolute bottom-0 left-0 w-10 h-0.5 bg-primary"></span>
            </h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-neutral-medium hover:text-primary transition flex items-center">
                <i className="fas fa-chevron-right text-xs mr-2 text-primary"></i> Delhi NCR
              </a></li>
              <li><a href="#" className="text-neutral-medium hover:text-primary transition flex items-center">
                <i className="fas fa-chevron-right text-xs mr-2 text-primary"></i> Mumbai
              </a></li>
              <li><a href="#" className="text-neutral-medium hover:text-primary transition flex items-center">
                <i className="fas fa-chevron-right text-xs mr-2 text-primary"></i> Bangalore
              </a></li>
              <li><a href="#" className="text-neutral-medium hover:text-primary transition flex items-center">
                <i className="fas fa-chevron-right text-xs mr-2 text-primary"></i> Hyderabad
              </a></li>
              <li><a href="#" className="text-neutral-medium hover:text-primary transition flex items-center">
                <i className="fas fa-chevron-right text-xs mr-2 text-primary"></i> Chennai
              </a></li>
              <li><a href="#" className="text-neutral-medium hover:text-primary transition flex items-center">
                <i className="fas fa-chevron-right text-xs mr-2 text-primary"></i> Kolkata
              </a></li>
            </ul>
          </div>
          
          {/* Contact & Social Media */}
          <div>
            <h3 className="text-lg font-semibold mb-4 font-poppins relative">
              Connect With Us
              <span className="absolute bottom-0 left-0 w-10 h-0.5 bg-primary"></span>
            </h3>
            <div className="flex flex-wrap gap-3 mb-6">
              {footerLinks.socialMedia.map((social, index) => (
                <a 
                  key={index}
                  href={social.path} 
                  className="bg-white bg-opacity-10 hover:bg-primary text-white w-9 h-9 rounded-full flex items-center justify-center transition-colors"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <i className={social.icon}></i>
                </a>
              ))}
            </div>
            <div className="space-y-3 text-sm text-neutral-medium">
              <div className="flex items-start">
                <i className="fas fa-map-marker-alt mt-1 mr-3 text-primary"></i>
                <span>123 Property Lane, Real Estate City, India 110001</span>
              </div>
              <div className="flex items-center">
                <i className="fas fa-phone-alt mr-3 text-primary"></i>
                <span>+91 1234 567 890</span>
              </div>
              <div className="flex items-center">
                <i className="fas fa-envelope mr-3 text-primary"></i>
                <span>info@propertyadda.com</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Property Types */}
        <div className="mt-10 pt-6 border-t border-neutral-medium border-opacity-20">
          <h4 className="text-base font-semibold mb-4">Property Types</h4>
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 text-sm text-neutral-medium">
            <a href="#" className="hover:text-primary transition">Apartments</a>
            <a href="#" className="hover:text-primary transition">Villas</a>
            <a href="#" className="hover:text-primary transition">Plots</a>
            <a href="#" className="hover:text-primary transition">Builder Floors</a>
            <a href="#" className="hover:text-primary transition">PentHouses</a>
            <a href="#" className="hover:text-primary transition">Studio Apartments</a>
            <a href="#" className="hover:text-primary transition">Farm Houses</a>
            <a href="#" className="hover:text-primary transition">Commercial Spaces</a>
            <a href="#" className="hover:text-primary transition">Office Spaces</a>
            <a href="#" className="hover:text-primary transition">Retail Shops</a>
            <a href="#" className="hover:text-primary transition">Land</a>
            <a href="#" className="hover:text-primary transition">Warehouses</a>
          </div>
        </div>
        
        {/* Legal Links & Copyright */}
        <div className="flex flex-col md:flex-row justify-between items-center pt-8 mt-8 border-t border-neutral-medium border-opacity-20 text-sm text-neutral-medium">
          <p>© {year} PropertyAdda. All rights reserved.</p>
          <div className="flex flex-wrap justify-center gap-5 mt-4 md:mt-0">
            <a href="#" className="hover:text-primary transition">Terms & Conditions</a>
            <a href="#" className="hover:text-primary transition">Privacy Policy</a>
            <a href="#" className="hover:text-primary transition">Disclaimer</a>
            <a href="#" className="hover:text-primary transition">Feedback</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
