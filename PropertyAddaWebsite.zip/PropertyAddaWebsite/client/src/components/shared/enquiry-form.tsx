import { useState } from "react";

interface EnquiryFormProps {
  title?: string;
  subtitle?: string;
  compact?: boolean;
  className?: string;
}

export function EnquiryForm({ title = "Have a Question?", subtitle = "Fill out the form below and our experts will get in touch with you shortly.", compact = false, className = "" }: EnquiryFormProps) {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [requirement, setRequirement] = useState("");
  const [message, setMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // In a real app, you would submit this to your API
    console.log("Contact form submission:", { name, email, phone, requirement, message });
    
    // Simulate API call
    setTimeout(() => {
      // Reset form
      setName("");
      setEmail("");
      setPhone("");
      setRequirement("");
      setMessage("");
      setIsSubmitting(false);
      setIsSuccess(true);
      
      // Reset success message after 5 seconds
      setTimeout(() => {
        setIsSuccess(false);
      }, 5000);
    }, 1000);
  };

  return (
    <div className={`bg-white rounded-lg shadow-lg p-6 ${className}`}>
      {!isSuccess ? (
        <>
          <div className="text-center mb-6">
            <h3 className="text-xl font-bold font-poppins mb-2">{title}</h3>
            <p className="text-neutral-dark text-sm">{subtitle}</p>
          </div>
          
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label htmlFor="name" className="block text-sm font-medium text-neutral-dark mb-1">
                Name <span className="text-primary">*</span>
              </label>
              <input 
                type="text" 
                id="name" 
                className="w-full p-3 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none" 
                placeholder="Your Full Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
            
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-neutral-dark mb-1">
                Email <span className="text-primary">*</span>
              </label>
              <input 
                type="email" 
                id="email" 
                className="w-full p-3 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none" 
                placeholder="Your Email Address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-neutral-dark mb-1">
                Phone <span className="text-primary">*</span>
              </label>
              <input 
                type="tel" 
                id="phone" 
                className="w-full p-3 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none" 
                placeholder="Your Phone Number"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
              />
            </div>
            
            <div className="md:col-span-2">
              <label htmlFor="requirement" className="block text-sm font-medium text-neutral-dark mb-1">
                Requirement <span className="text-primary">*</span>
              </label>
              <select 
                id="requirement" 
                className="w-full p-3 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none bg-white"
                value={requirement}
                onChange={(e) => setRequirement(e.target.value)}
                required
              >
                <option value="">Select Your Requirement</option>
                <option value="buy">Buy Property</option>
                <option value="rent">Rent Property</option>
                <option value="service">Home Services</option>
                <option value="sell">Sell Property</option>
                <option value="other">Other</option>
              </select>
            </div>
            
            {!compact && (
              <div className="md:col-span-2">
                <label htmlFor="message" className="block text-sm font-medium text-neutral-dark mb-1">
                  Message
                </label>
                <textarea 
                  id="message" 
                  rows={4} 
                  className="w-full p-3 border border-neutral-medium rounded-md focus:ring-2 focus:ring-primary focus:outline-none" 
                  placeholder="Additional details about your requirement..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                ></textarea>
              </div>
            )}
            
            <div className="md:col-span-2">
              <button 
                type="submit" 
                className="w-full bg-gradient-to-r from-primary to-secondary text-white font-medium py-3 px-6 rounded-md hover:shadow-lg transition flex justify-center items-center"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Submitting...
                  </>
                ) : (
                  <>
                    <i className="fas fa-paper-plane mr-2"></i> Submit Enquiry
                  </>
                )}
              </button>
              <p className="text-xs text-center text-neutral-dark mt-3">
                By submitting this form, you agree to our <a href="#" className="text-primary hover:underline">Privacy Policy</a>
              </p>
            </div>
          </form>
        </>
      ) : (
        <div className="text-center py-8">
          <div className="mx-auto w-16 h-16 bg-success bg-opacity-10 rounded-full flex items-center justify-center mb-4">
            <i className="fas fa-check-circle text-success text-2xl"></i>
          </div>
          <h3 className="text-xl font-bold font-poppins mb-2">Thank You!</h3>
          <p className="text-neutral-dark">
            Your enquiry has been submitted successfully. Our team will contact you shortly.
          </p>
        </div>
      )}
    </div>
  );
}