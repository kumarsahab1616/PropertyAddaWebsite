import { useState, useEffect } from "react";
import { EnquiryForm } from "./enquiry-form";

export function FloatingEnquiryButton() {
  const [isOpen, setIsOpen] = useState(false);
  const [showButton, setShowButton] = useState(true); // Always show button by default
  const [hasShownPopup, setHasShownPopup] = useState(false);
  
  // Use page-specific storage instead of session storage
  // This makes the form show once per page, not once per session
  useEffect(() => {
    // Get the current page path
    const currentPath = window.location.pathname;
    
    // Check if we've already shown the popup on this specific page
    const pagePopupShown = localStorage.getItem(`enquiryFormShown_${currentPath}`);
    
    if (pagePopupShown === "true") {
      setHasShownPopup(true);
    } else {
      // Show the enquiry form automatically after 3 seconds
      // but only if it hasn't been shown on this page before
      const initialTimeout = setTimeout(() => {
        setIsOpen(true);
        setHasShownPopup(true);
        
        // Save that we've shown the form on this specific page
        localStorage.setItem(`enquiryFormShown_${currentPath}`, "true");
      }, 3000);
      
      return () => {
        clearTimeout(initialTimeout);
      };
    }
  }, []);

  // Simple close handler without any flash effect
  const handleCloseForm = () => {
    setIsOpen(false);
  };

  return (
    <>
      {/* Floating Button */}
      <div className="fixed right-5 bottom-5 z-30 flex flex-col items-end">
        <button
          onClick={() => setIsOpen(true)}
          className="bg-gradient-to-r from-primary to-secondary text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center"
          aria-label="Open Enquiry Form"
        >
          <i className="fas fa-comment-alt text-xl"></i>
        </button>
      </div>

      {/* Enquiry Form Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50 animate-fadeIn">
          <div className="relative bg-white rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto animate-scaleIn">
            <button
              onClick={handleCloseForm}
              className="absolute top-3 right-3 text-neutral-dark hover:text-primary rounded-full p-2 z-10"
              aria-label="Close"
            >
              <i className="fas fa-times"></i>
            </button>
            <EnquiryForm 
              title="Quick Enquiry" 
              subtitle="Get a quick response from our property experts" 
              compact={true} 
            />
          </div>
        </div>
      )}
    </>
  );
}